# 🔥📜 Red Team Grimoire 📜🔥
A forbidden collection of Red Team sorcery

Step into the Red Team Grimoire, a tome of digital witchcraft where dark magic meets cybersecurity. Here, you’ll find arcane spells and forbidden rituals designed to manipulate the fabric of enterprise defenses. Each incantation has been meticulously crafted and tested in the shadows of real-world assessments.

<p align="center">
  <img src="https://github.com/user-attachments/assets/12174c84-3c57-49ee-bea2-a08c2b11938e" width="400"/>
</p>

## 🔮 Contents of the Grimoire 🔮

🎭 [Doppelganger](./Doppelganger) – Advanced LSASS Dumper with PPL Bypass. Clone lsass.exe, dump it stealthily, and exfiltrate credentials under a veil of arcane obfuscation.

💀 [HollowReaper](./HollowReaper) – Process hollowing ritual. Pierce the shell of a benign process and inject your custom payload within.

🕯️ TGTConjuring - Conjure Kerberos TGTs from the void. Inject tickets to impersonate users across the domain.

🧟 NecroMirror - Reflect system shadows. Dump SAM, SECURITY, SOFTWARE, and SYSTEM from Volume Shadow Copies.

🩸 SoulDumper - Rip the spirit from LSASS and claim its secrets.

----------------------------------------------------------------------

These spells are tools of the trade for the cunning and the daring. Wield them wisely, for power without caution invites ruin.

✨ *May your exploits be as elusive as the whispers of the void* ✨
