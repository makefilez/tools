#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <dbghelp.h>
#include "defs.h"

BOOL ResolveAllApis(void);
