#pragma once

// Retrieve kernel address
unsigned long long getKBAddr(void);

// Get OS version
int GetOSVersion();